import jwt from 'jsonwebtoken'
import bcrypt from 'bcrypt'
import prisma from '../services/prismaClient.js'
import crypto from 'crypto'
import '../config/env.js'
import { demoMailMode, sendOtpEmail } from '../services/emailService.js'

/**
 * POST /api/auth/send-otp
 * Generates and sends a 6-digit OTP to the user's email.
 */
export async function sendOtp(req, res) {
  const { email } = req.body
  if (!email) return res.status(400).json({ error: 'Email is required.' })

  const otp = crypto.randomInt(100000, 999999).toString()
  const expiryMinutes = parseInt(process.env.OTP_EXPIRY_MINUTES) || 10
  const expiresAt = new Date(Date.now() + expiryMinutes * 60000)

  try {
    console.log(`Attempting to send OTP to: ${email}`)
    // 1. Save or Update OTP in DB
    const otpRecord = await prisma.oneTimePassword.create({
      data: { email, otp, expiresAt },
    })
    console.log(`OTP record created for ${email}`)

    await sendOtpEmail({ to: email, otp, expiryMinutes })
    console.log(`OTP email sent to ${email}`)

    if (demoMailMode) {
      console.log(`DEV OTP for ${email}: ${otp}`)
      return res.status(200).json({
        message: 'OTP sent successfully in local demo mode.',
        demoOtp: otp,
      })
    }

    return res.status(200).json({ message: 'OTP sent successfully.' })
  } catch (err) {
    console.error('CRITICAL: Error in sendOtp:', err)
    return res.status(500).json({ error: `Failed to send OTP. Original Error: ${err.message}` })
  }
}

/**
 * POST /api/auth/verify-otp
 * Verifies the 6-digit OTP and issues a JWT.
 */
export async function verifyOtp(req, res) {
  const { email, otp } = req.body
  if (!email || !otp) return res.status(400).json({ error: 'Email and OTP are required.' })

  try {
    // 1. Find the latest unexpired OTP for this email
    const record = await prisma.oneTimePassword.findFirst({
      where: {
        email,
        otp,
        expiresAt: { gte: new Date() },
      },
      orderBy: { createdAt: 'desc' },
    })

    if (!record) {
      return res.status(400).json({ error: 'Invalid or expired OTP.' })
    }

    // 2. Consume the OTP (delete all OTPs for this email to be secure)
    await prisma.oneTimePassword.deleteMany({ where: { email } })

    // 3. Find or Create User
    let user = await prisma.user.findUnique({
      where: { email },
    })

    if (!user) {
      user = await prisma.user.create({
        data: { email },
      })
    }

    // 4. Generate JWT
    const token = jwt.sign(
      { id: user.id, email: user.email, isAdmin: user.isAdmin },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    )

    return res.status(200).json({
      message: 'Logged in successfully.',
      token,
      user: {
        id: user.id,
        email: user.email,
        isAdmin: user.isAdmin,
      },
    })
  } catch (err) {
    console.error('Error in verifyOtp:', err)
    return res.status(500).json({ error: 'Authentication failed.' })
  }
}

/**
 * POST /api/auth/register
 * Registers a new user with name, email, password and sends OTP for verification.
 */
export async function registerUser(req, res) {
  const { name, email, password } = req.body
  if (!name || !email || !password) {
    return res.status(400).json({ error: 'Name, email, and password are required.' })
  }

  if (password.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters long.' })
  }

  try {
    // Check if user already exists
    const existingUser = await prisma.user.findUnique({
      where: { email },
    })

    if (existingUser) {
      return res.status(400).json({ error: 'User with this email already exists.' })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Generate and send OTP
    const otp = crypto.randomInt(100000, 999999).toString()
    const expiryMinutes = parseInt(process.env.OTP_EXPIRY_MINUTES) || 10
    const expiresAt = new Date(Date.now() + expiryMinutes * 60000)

    await prisma.signupRequest.upsert({
      where: { email },
      update: {
        name,
        password: hashedPassword,
        otp,
        expiresAt,
        createdAt: new Date(),
      },
      create: {
        name,
        email,
        password: hashedPassword,
        otp,
        expiresAt,
      },
    })

    await sendOtpEmail({ to: email, otp, expiryMinutes })
    if (demoMailMode) {
      console.log(`DEV SIGNUP OTP for ${email}: ${otp}`)
      return res.status(200).json({
        message: 'Registration initiated. OTP sent successfully in local demo mode.',
        demoOtp: otp,
      })
    }

    return res.status(200).json({ message: 'Registration initiated. Please check your email for verification code.' })
  } catch (err) {
    console.error('Error in registerUser:', err)
    return res.status(500).json({ error: 'Registration failed. Please try again.' })
  }
}

/**
 * POST /api/auth/verify-signup-otp
 * Verifies the OTP for signup completion.
 */
export async function verifySignupOtp(req, res) {
  const { email, otp } = req.body
  if (!email || !otp) {
    return res.status(400).json({ error: 'Email and OTP are required.' })
  }

  try {
    const pendingSignup = await prisma.signupRequest.findUnique({
      where: { email },
    })

    if (!pendingSignup || pendingSignup.otp !== otp || pendingSignup.expiresAt < new Date()) {
      return res.status(400).json({ error: 'Invalid or expired OTP.' })
    }

    const existingUser = await prisma.user.findUnique({
      where: { email },
    })

    if (existingUser) {
      await prisma.signupRequest.deleteMany({ where: { email } })
      return res.status(400).json({ error: 'User already exists. Please login instead.' })
    }

    const user = await prisma.user.create({
      data: {
        name: pendingSignup.name,
        email: pendingSignup.email,
        password: pendingSignup.password,
        isAdmin: false,
      },
    })

    await prisma.signupRequest.deleteMany({ where: { email } })

    const token = jwt.sign(
      { id: user.id, email: user.email, isAdmin: user.isAdmin },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    )

    return res.status(200).json({
      message: 'Account verified and logged in successfully.',
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        isAdmin: user.isAdmin,
      },
    })
  } catch (err) {
    console.error('Error in verifySignupOtp:', err)
    return res.status(500).json({ error: 'Verification failed.' })
  }
}

/**
 * POST /api/auth/login
 * Logs in a user with email and password (for applicants).
 */
export async function loginWithPassword(req, res) {
  const { email, password } = req.body
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' })
  }

  try {
    // Find user
    const user = await prisma.user.findUnique({
      where: { email },
    })

    if (!user || !user.password) {
      return res.status(400).json({ error: 'Invalid email or password.' })
    }

    // Check password
    const isValidPassword = await bcrypt.compare(password, user.password)
    if (!isValidPassword) {
      return res.status(400).json({ error: 'Invalid email or password.' })
    }

    // Generate JWT
    const token = jwt.sign(
      { id: user.id, email: user.email, isAdmin: user.isAdmin },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    )

    return res.status(200).json({
      message: 'Logged in successfully.',
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        isAdmin: user.isAdmin,
      },
    })
  } catch (err) {
    console.error('Error in loginWithPassword:', err)
    return res.status(500).json({ error: 'Login failed.' })
  }
}
