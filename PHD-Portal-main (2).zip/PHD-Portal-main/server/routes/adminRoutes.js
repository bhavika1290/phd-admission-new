import express from 'express'
import { authenticate, requireAdmin } from '../middleware/authMiddleware.js'
import {
  updateApplicationStatus,
  getEmailTemplates,
  createEmailTemplate,
  updateEmailTemplate,
  deleteEmailTemplate,
  sendBulkEmail,
} from '../controllers/adminController.js'

const router = express.Router()

// All routes require authentication and admin access
router.use(authenticate)
router.use(requireAdmin)

// Status Management
router.patch('/application/:applicationId/status', updateApplicationStatus)

// Email Templates
router.get('/email-templates', getEmailTemplates)
router.post('/email-templates', createEmailTemplate)
router.put('/email-templates/:templateId', updateEmailTemplate)
router.delete('/email-templates/:templateId', deleteEmailTemplate)

// Bulk Email
router.post('/bulk-email', sendBulkEmail)

export default router
