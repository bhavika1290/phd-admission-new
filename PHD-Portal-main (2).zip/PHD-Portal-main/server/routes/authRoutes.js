import express from 'express'
import { sendOtp, verifyOtp, registerUser, verifySignupOtp, loginWithPassword } from '../controllers/authController.js'

const router = express.Router()

router.post('/send-otp', sendOtp)
router.post('/verify-otp', verifyOtp)
router.post('/register', registerUser)
router.post('/verify-signup-otp', verifySignupOtp)
router.post('/login', loginWithPassword)

export default router
