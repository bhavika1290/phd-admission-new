import React, { useState, useEffect } from 'react'
import toast from 'react-hot-toast'
import { CheckCircle, Clock, Ban, Loader2, Save, UserCheck, ShieldAlert, Circle, Check, Search, Filter } from 'lucide-react'
import { getAllApplications, updateApplicationStatus } from '../services/api'

export default function AdminStatusManagement() {
  const [applications, setApplications] = useState([])
  const [loading, setLoading] = useState(true)
  const [updatingId, setUpdatingId] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')

  useEffect(() => { fetchApplications() }, [])

  const fetchApplications = async () => {
    setLoading(true)
    try {
      const res = await getAllApplications()
      setApplications(res.data.applications || [])
    } catch {
      toast.error('Scholastic records inaccessible')
    } finally {
      setLoading(false)
    }
  }

  const handleStatusChange = async (id, newStatus) => {
    setUpdatingId(id)
    try {
      await updateApplicationStatus(id, newStatus)
      toast.success(`Marked as ${newStatus}`)
      setApplications(prev => prev.map(a => a.id === id ? { ...a, status: newStatus } : a))
    } catch {
      toast.error('Modification failure')
    } finally {
      setUpdatingId(null)
    }
  }

  const filteredApps = applications.filter(a => 
    a.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    a.email?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  if (loading) return (
    <div className="flex flex-col items-center justify-center h-96 space-y-8">
      <div className="spinner border-t-[#003366]" />
      <p className="text-[10px] font-black text-[#003366] uppercase tracking-[0.4em] animate-pulse">Synchronizing Registry Core...</p>
    </div>
  )

  const statuses = [
    { id: 'pending', label: 'Pending' },
    { id: 'shortlisted', label: 'Shortlisted' },
    { id: 'waitlisted', label: 'Waitlisted' },
    { id: 'rejected', label: 'Rejected' },
    { id: 'selected', label: 'Selected' }
  ]

  return (
    <div className="space-y-8 animate-fade-up">
      {/* Search Utility */}
      <div className="flex justify-end pr-4">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-[#003366]/30 group-focus-within:text-[#003366] transition-colors" size={16} />
          <input 
            type="text" 
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            placeholder="Search Candidates..." 
            className="h-10 pl-12 pr-6 bg-white border border-blue-50 rounded-xl font-bold text-[10px] uppercase tracking-widest text-[#001122] outline-none focus:ring-4 focus:ring-[#003366]/5 w-72 transition-all shadow-sm"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filteredApps.map((app) => (
          <div key={app.id} className="glass-card !p-5 border-blue-50 shadow-md hover:shadow-xl transition-all duration-500 bg-white group">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="flex items-center gap-5">
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-[#003366] flex items-center justify-center border border-blue-100 group-hover:bg-[#003366] group-hover:text-white transition-all shadow-sm">
                  <UserCheck size={20} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-[#001122] tracking-tight">{app.full_name || app.name}</h3>
                  <div className="flex flex-wrap gap-3 mt-1 underline decoration-blue-100 underline-offset-4">
                    <span className="text-[9px] font-black text-[#003366]/40 uppercase tracking-widest">ID: #{app.id}</span>
                    <span className="text-[9px] font-bold text-[#4169E1] lowercase italic">{app.email}</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {statuses.map(s => {
                  const isActive = (app.status || 'pending') === s.id
                  const isUpdating = updatingId === app.id
                  return (
                    <button
                      key={s.id}
                      onClick={() => handleStatusChange(app.id, s.id)}
                      disabled={isUpdating}
                      className={`px-4 py-1.5 rounded-full text-[8.5px] font-black uppercase tracking-widest border transition-all duration-300 flex items-center gap-1.5 ${
                        isActive 
                          ? 'bg-[#003366] border-[#003366] text-white shadow-lg scale-105' 
                          : 'bg-white border-blue-50 text-[#001122]/30 hover:border-blue-100 hover:text-[#001122]/60'
                      }`}
                    >
                      {isActive ? <Check size={10} strokeWidth={4} /> : <Circle size={4} className="fill-current opacity-20" />}
                      {s.label}
                    </button>
                  )
                })}
                {updatingId === app.id && <Loader2 size={14} className="animate-spin text-[#003366] ml-2" />}
              </div>
            </div>
          </div>
        ))}
        {filteredApps.length === 0 && (
          <div className="py-20 text-center glass-card border-dashed border-2 border-blue-100 opacity-40">
             <p className="text-[11px] font-black text-[#003366] uppercase tracking-widest">No candidates discovered in this domain</p>
          </div>
        )}
      </div>
    </div>
  )
}
