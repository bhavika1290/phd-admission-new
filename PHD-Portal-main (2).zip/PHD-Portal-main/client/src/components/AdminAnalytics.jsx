import React, { useState, useEffect } from 'react'
import toast from 'react-hot-toast'
import { Loader2, TrendingUp, Users, CheckCircle, Clock, Ban, PieChart, BarChart } from 'lucide-react'
import { getAllApplications } from '../services/api'

export default function AdminAnalytics() {
  const [applications, setApplications] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchAnalytics()
  }, [])

  const fetchAnalytics = async () => {
    setLoading(true)
    try {
      const res = await getAllApplications()
      setApplications(res.data.applications || [])
    } catch {
      toast.error('Failed to load analytics data.')
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-96 space-y-6">
        <div className="spinner border-t-[#003366]" />
        <p className="text-[10px] font-black text-[#003366] uppercase tracking-[0.4em] animate-pulse">Aggregating Global Intelligence...</p>
      </div>
    )
  }

  const totalApplications = applications.length
  const shortlisted = applications.filter(a => a.status === 'shortlisted').length
  const waitlisted = applications.filter(a => a.status === 'waitlisted').length
  const rejected = applications.filter(a => a.status === 'rejected').length
  const selected = applications.filter(a => a.status === 'selected').length
  const femalesCount = applications.filter(a => a.gender?.toLowerCase() === 'female').length

  const categoryDist = {}
  applications.forEach(a => {
    const cat = a.category || 'General'
    categoryDist[cat] = (categoryDist[cat] || 0) + 1
  })

  const researchDist = {}
  applications.forEach(a => {
    const area = a.research_area || 'Not specified'
    researchDist[area] = (researchDist[area] || 0) + 1
  })

  const topResearchAreas = Object.entries(researchDist)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5)

  const StatCard = ({ label, value, icon: Icon }) => (
    <div className="glass-card !p-6 animate-fade-up border-blue-50 shadow-md hover:shadow-xl transition-all duration-500 bg-white">
      <div className="flex items-center justify-between mb-4">
        <div className="p-3 rounded-xl bg-blue-50 text-[#003366] shadow-sm border border-blue-100">
          <Icon size={18} />
        </div>
        <span className="text-2xl font-bold tracking-tight text-[#001122]">{value}</span>
      </div>
      <p className="text-[9px] font-black text-[#003366]/40 uppercase tracking-widest">{label}</p>
      <div className="w-full bg-blue-50 h-1 rounded-full overflow-hidden mt-4">
        <div className="h-full bg-[#003366] opacity-30" style={{ width: '100%' }} />
      </div>
    </div>
  )

  return (
    <div className="space-y-8 animate-fade-up">
      {/* Quick Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard label="Total Applicants" value={totalApplications} icon={Users} />
        <StatCard label="Shortlisted" value={shortlisted} icon={CheckCircle} />
        <StatCard label="Waitlisted" value={waitlisted} icon={Clock} />
        <StatCard label="Rejected" value={rejected} icon={Ban} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Pipeline Distribution */}
        <div className="glass-card !p-8 border-blue-50 shadow-xl bg-white">
           <div className="flex items-center gap-4 mb-10">
              <div className="p-3 rounded-xl bg-[#003366] text-white shadow-lg">
                 <BarChart size={18} />
              </div>
              <h3 className="text-xl font-bold font-heading text-[#001122]">Pipeline Progression</h3>
           </div>
           
           <div className="space-y-6">
            {[
              { status: 'Formal Selection', count: selected, color: 'bg-[#003366]' },
              { status: 'Shortlisted Pool', count: shortlisted, color: 'bg-[#4169E1]' },
              { status: 'Pending Review', count: applications.filter(a => a.status === 'pending').length, color: 'bg-blue-300' },
              { status: 'Rejection Archives', count: rejected, color: 'bg-red-400' },
            ].map(item => {
              const percentage = totalApplications > 0 ? (item.count / totalApplications) * 100 : 0
              return (
                <div key={item.status} className="space-y-3">
                  <div className="flex justify-between items-end">
                    <span className="text-[9px] font-black text-[#003366]/40 uppercase tracking-widest">{item.status}</span>
                    <span className="text-sm font-bold text-[#001122]">{item.count}</span>
                  </div>
                  <div className="w-full bg-blue-50 rounded-full h-2 overflow-hidden border border-blue-100/50">
                    <div
                      className={`${item.color} h-full transition-all duration-1000 ease-out`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Demographics Analysis */}
        <div className="glass-card !p-8 border-blue-50 shadow-xl bg-white">
            <div className="flex items-center gap-4 mb-10">
              <div className="p-3 rounded-xl bg-blue-50 text-[#003366] border border-blue-100">
                 <PieChart size={18} />
              </div>
              <h3 className="text-xl font-bold font-heading text-[#001122]">Demographic Diversity</h3>
           </div>

           <div className="flex flex-col md:flex-row items-center justify-around gap-8 py-4">
              <div className="text-center group">
                 <div className="w-24 h-24 rounded-full border-8 border-blue-50 border-t-[#003366] flex items-center justify-center shadow-lg bg-white mb-4 group-hover:scale-105 transition-transform">
                    <span className="text-xl font-bold text-[#001122]">{totalApplications > 0 ? ((femalesCount / totalApplications) * 100).toFixed(0) : 0}%</span>
                 </div>
                 <p className="text-[9px] font-black text-[#003366]/40 uppercase tracking-widest italic">Female scholars</p>
              </div>
              <div className="text-center group">
                 <div className="w-24 h-24 rounded-full border-8 border-blue-50 border-t-blue-100 flex items-center justify-center shadow-lg bg-white mb-4 group-hover:scale-105 transition-transform">
                    <span className="text-xl font-bold text-[#001122]">{totalApplications > 0 ? (((totalApplications - femalesCount) / totalApplications) * 100).toFixed(0) : 0}%</span>
                 </div>
                 <p className="text-[9px] font-black text-[#003366]/40 uppercase tracking-widest italic">Male scholars</p>
              </div>
           </div>

           <div className="mt-10 p-5 rounded-2xl bg-blue-50/50 border border-blue-50 flex items-center justify-between">
              <div>
                 <p className="text-[9px] font-black text-[#003366]/30 uppercase tracking-widest">Growth Trend</p>
                 <p className="text-2xl font-bold text-[#001122] mt-1">Positive Intelligence</p>
              </div>
              <div className="p-3 rounded-xl bg-white text-[#003366] shadow-sm border border-blue-50">
                 <TrendingUp size={20} />
              </div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Classification Summary */}
        <div className="glass-card !p-8 border-blue-50 shadow-xl bg-white">
          <h3 className="text-xl font-bold font-heading text-[#001122] mb-8 mr-2 underline decoration-blue-100 underline-offset-8">Classification Mix</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {Object.entries(categoryDist).map(([cat, count]) => (
              <div key={cat} className="p-5 rounded-2xl bg-blue-50/30 border border-blue-50 hover:border-[#003366] transition-all group/cat text-center">
                <p className="text-[8px] font-black text-[#003366]/30 uppercase tracking-widest mb-1 group-hover/cat:text-[#003366] transition-colors">{cat}</p>
                <p className="text-2xl font-bold text-[#001122]">{count}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Top Research Areas */}
        <div className="glass-card !p-8 border-blue-50 shadow-xl bg-white">
          <h3 className="text-xl font-bold font-heading text-[#001122] mb-8 underline decoration-blue-100 underline-offset-8">Top Research Interests</h3>
          <div className="space-y-3">
            {topResearchAreas.map(([area, count], idx) => (
              <div key={area} className="flex items-center justify-between p-4 rounded-xl bg-blue-50/20 border border-transparent hover:border-blue-50 transition-all group/node">
                <div className="flex items-center gap-4">
                  <span className="w-8 h-8 rounded-lg bg-[#003366] flex items-center justify-center text-[10px] font-black text-white">0{idx+1}</span>
                  <span className="text-[10px] font-bold text-[#001122] uppercase tracking-widest">{area}</span>
                </div>
                <span className="text-xl font-bold text-[#003366]">{count}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
