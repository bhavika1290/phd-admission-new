import axios from 'axios'

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5001'

const api = axios.create({
  baseURL: `${BASE_URL}/api`,
  headers: { 'Content-Type': 'application/json' },
})

// Attach JWT token from localStorage on every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('phd_token')
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
}, (error) => {
  return Promise.reject(error)
})

export const sendOtp = (email) =>
  api.post('/auth/send-otp', { email })

export const verifyOtp = (email, otp) =>
  api.post('/auth/verify-otp', { email, otp })

export const registerUser = (name, email, password) =>
  api.post('/auth/register', { name, email, password })

export const verifySignupOtp = (email, otp) =>
  api.post('/auth/verify-signup-otp', { email, otp })

export const loginWithPassword = (email, password) =>
  api.post('/auth/login', { email, password })

// Application endpoints
export const submitApplication = (payload) =>
  api.post('/application', payload)

export const finalizeApplication = (payload) =>
  api.post('/application/finalize', payload)

export const getMyApplication = () =>
  api.get('/application/me')

// Admin endpoints
export const checkIsAdmin = () =>
  api.get('/is-admin') // Matches applicationRoutes.js mounting on /api

export const getAllApplications = (filters = {}) =>
  api.get('/applications', { params: filters })

export const exportApplications = async (filters = {}) => {
  const token = localStorage.getItem('phd_token')

  const response = await fetch(
    `${BASE_URL}/api/export?${new URLSearchParams(filters)}`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  )

  if (!response.ok) throw new Error('Export failed')

  const blob = await response.blob()
  const url = window.URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `phd_applications_${Date.now()}.xlsx`
  a.click()
  window.URL.revokeObjectURL(url)
}

// Admin endpoints (prefixed with /admin as per adminRoutes.js)
export const updateApplicationStatus = (applicationId, status) =>
  api.patch(`/admin/application/${applicationId}/status`, { status })

export const getEmailTemplates = () =>
  api.get('/admin/email-templates')

export const createEmailTemplate = (templateData) =>
  api.post('/admin/email-templates', templateData)

export const updateEmailTemplate = (templateId, templateData) =>
  api.put(`/admin/email-templates/${templateId}`, templateData)

export const deleteEmailTemplate = (templateId) =>
  api.delete(`/admin/email-templates/${templateId}`)

export const sendBulkEmail = (payload) =>
  api.post('/admin/bulk-email', payload)

export default api
